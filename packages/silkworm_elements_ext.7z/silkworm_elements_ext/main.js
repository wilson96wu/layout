'use strict';

module.exports = {
  load () {
    // execute when package loaded
  },

  unload () {
    // execute when package unloaded
  },
  messages: {
   // register your ipc messages here
  },
};